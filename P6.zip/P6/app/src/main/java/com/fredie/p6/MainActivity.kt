package com.fredie.p6

import android.content.DialogInterface
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.PorterDuff
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn.setOnClickListener {
            var builder =AlertDialog.Builder(this)
                .setTitle("Alert Dialogue")
                .setMessage("This is a alert message")

            builder.setPositiveButton("Yes") { dialog, which ->
                Toast.makeText(this,"Thanks for liking this feature",Toast.LENGTH_LONG).show()
            }

            builder.setNegativeButton("No"){ dialog, which ->
                Toast.makeText(this,"Ok we'll make it better",Toast.LENGTH_LONG).show()

            }

            var dialog = builder.create()
            dialog.show()
        }

        show_simple_snackbar.setOnClickListener {
            var snackbar = Snackbar.make(it,"This is a snackbar",Snackbar.LENGTH_LONG)
            snackbar.show()
        }

        show_action_snackbar.setOnClickListener {
            show_action_snackbar.background.setColorFilter(Color.parseColor("#d2a459"),PorterDuff.Mode.MULTIPLY)
            //show_action_snackbar.setBackgroundColor(ContextCompat.getColor(this,R.color.colorPrimary))
            var snackbar = Snackbar.make(it,"Button's background color changed ",Snackbar.LENGTH_LONG)
            snackbar.setAction("UNDO") {
                show_action_snackbar.background.clearColorFilter()
            }
            snackbar.show()
        }

        show_custom_snackbar.setOnClickListener {
            var snackbar = Snackbar.make(it,"This is a custom snackbar",Snackbar.LENGTH_LONG)
            var snackbarView = snackbar.view
            var snackbarText = snackbarView.findViewById<TextView>(android.support.design.R.id.snackbar_text)
            snackbarView.setBackgroundColor(Color.parseColor("#2c4152"))
            snackbarText.setTextColor(Color.parseColor("#d2a459"))
            snackbar.show()
            
        }


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.product_catalog,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when(item!!.itemId) {

            R.id.football ->{
                Toast.makeText(this,"you selected "+item.title,Toast.LENGTH_LONG).show()
                return true
            }

            R.id.football_studs ->{
                Toast.makeText(this,"you selected "+item.title,Toast.LENGTH_LONG).show()
                return true
            }

            R.id.jersey ->{
                Toast.makeText(this,"you selected "+item.title,Toast.LENGTH_LONG).show()
                return true
            }

            else -> {
                return super.onOptionsItemSelected(item)
            }
        }
    }
}
