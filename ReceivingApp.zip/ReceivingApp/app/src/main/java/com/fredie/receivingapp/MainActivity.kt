package com.fredie.receivingapp

import android.content.Intent
import android.opengl.Visibility
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var intent = intent
        var action = intent.action
        var type= intent.type

        if(intent.action.equals(action) && type!=null){
            if(type.equals(intent.type)){
                handleText(intent)
            }

        } else{
            textView2.visibility=View.INVISIBLE
        }


    }

    private fun handleText(intent: Intent?) {
        var sharedText=intent!!.getStringExtra(Intent.EXTRA_TEXT)
        if(sharedText!=null){
            textView2.visibility = View.VISIBLE
            textView2.text=sharedText
            textView1.visibility=View.INVISIBLE
        }

    }
}
