package com.fredie.downloadimg

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.DialogInterface
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import java.io.InputStream

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var url = "https://besthqwallpapers.com/Uploads/8-2-2019/79859/thumb2-roberto-firmino-close-up-lfc-soccer-liverpool-fc.jpg"

        btn.setOnClickListener {
            DownloadImage().execute(url)
        }
    }

    override fun onBackPressed() {
        var builder = AlertDialog.Builder(this)
            .setTitle("Confirm Exit")
            .setMessage("Do you really want to exit the app ?")
            .setCancelable(false)
            .setPositiveButton("YES"){dialog, which ->
                finish()

            }
            .setNegativeButton("NO"){ dialog, which ->
                dialog.cancel()
            }

        var alertDialog = builder.create()
        alertDialog.show()

    }

    inner class DownloadImage : AsyncTask<String,Void,Bitmap>(){

        private lateinit var progressDialog:ProgressDialog

        override fun onPreExecute() {
            super.onPreExecute()

            progressDialog = ProgressDialog(this@MainActivity)
            progressDialog.setTitle("Downloading Image")
            progressDialog.setMessage("Please wait")
            progressDialog.setCancelable(false)
            progressDialog.isIndeterminate = false
            progressDialog.show()
        }

        override fun doInBackground(vararg URL: String?): Bitmap {

            var imageURL = URL[0]
            lateinit var bitmap : Bitmap
            try {
                var input:InputStream = java.net.URL(imageURL).openStream()
                bitmap = BitmapFactory.decodeStream(input)
            } catch (e:Exception){
                e.printStackTrace()
            }

            return bitmap
        }

        override fun onPostExecute(result: Bitmap?) {
            super.onPostExecute(result)
            progressDialog.dismiss()
            image_view.setImageBitmap(result)
        }


    }
}
