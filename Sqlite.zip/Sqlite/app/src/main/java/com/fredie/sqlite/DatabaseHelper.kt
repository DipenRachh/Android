package com.fredie.sqlite

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context): SQLiteOpenHelper(context, database_name,null,1) {
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        db!!.execSQL("DROP table IF exists + $table_name")
    }

    override fun onCreate(db: SQLiteDatabase?) {
        // TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        db!!.execSQL("create table $table_name( $col_1 Text PRIMARY KEY, $col_2 Text, $col_3 Text)")
    }

    companion object {
        const val database_name="college.db"
        const val table_name="student"
        const val col_1="id"
        const val col_2="name"
        const val col_3="age"

    }
    fun insert_data(id:String,name:String,age:String)
    {
        val db=this.writableDatabase
        val contentvalues= ContentValues()
        contentvalues.put(col_1,id)
        contentvalues.put(col_2,name)
        contentvalues.put(col_3,age)
        db.insert(table_name,null,contentvalues)


    }
    fun update_data(id:String,name:String,age:String): Boolean
    {
        val db=this.writableDatabase
        val contentValue= ContentValues()
        contentValue.put(col_1,id)
        contentValue.put(col_2,name)
        contentValue.put(col_3,age)
        db.update(table_name, contentValue, "id=?", arrayOf(id))
        return true
    }

    fun deleteAll() : Int {

        var db = this.writableDatabase
        return db.delete(table_name,null,null)

    }

    fun delete_data(id:String): Int
    {

        val db=this.writableDatabase
        return db.delete(table_name,"id=?", arrayOf(id))
    }

    val showdata: Cursor
        get()
        {
            val db = this.writableDatabase
            return db.rawQuery("select *from $table_name",null)
        }

}