package com.fredie.sqlite

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.SyncStateContract.Helpers.insert
import android.provider.SyncStateContract.Helpers.update
import android.support.v7.app.AlertDialog
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    internal var dbhelper=DatabaseHelper(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        insert()
        update()
        delete()
        show()
        deleteAll()

    }

    private fun deleteAll() {
        delete_all_button.setOnClickListener {
            var b = dbhelper.deleteAll()
            if(b>0){
                Toast.makeText(this,"All Data Deleted",Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this,"No Data Available",Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showDialog(title:String,msg:String)
    {
        val builder= AlertDialog.Builder(this)
        builder.setCancelable(true)
        builder.setTitle(title)
        builder.setMessage(msg)
        builder.show()
    }
    fun clear()
    {
        id.text = null
        name.text = null
        age.text = null
    }
    private fun insert()
    {
        insert_button.setOnClickListener()
        {
            if(id.text.toString().isEmpty() && name.text.toString().isEmpty() && age.text.toString().isEmpty())
            {
                Toast.makeText(this,"Please fill all data",Toast.LENGTH_LONG).show()
            } else {
                try {
                    dbhelper.insert_data(id.text.toString(),name.text.toString(),age.text.toString())
                    Toast.makeText(this,"Data Saved",Toast.LENGTH_LONG).show()
                    clear()

                }
                catch (e:Exception)
                {
                    e.printStackTrace()
                    Toast.makeText(this,"Couldn't Insert data",Toast.LENGTH_LONG).show()

                }
            }

        }
    }
    private fun update()
    {
        update_button.setOnClickListener()
        {
            if(id.text.toString().isEmpty() && name.text.toString().isEmpty() && age.text.toString().isEmpty()){
                Toast.makeText(this,"Please fill all data",Toast.LENGTH_LONG).show()
            } else {
                try
                {
                    var b:Boolean= dbhelper.update_data(id.text.toString(),name.text.toString(),age.text.toString())
                    if(b==true) {
                        Toast.makeText(this, "Data Updated successfully", Toast.LENGTH_LONG).show()

                    }
                    else
                    {
                        Toast.makeText(this, "Couldn't Update", Toast.LENGTH_LONG).show()

                    }
                    clear()
                }
                catch (e:Exception)
                {
                    e.printStackTrace()
                    Toast.makeText(this,"Error!!",Toast.LENGTH_LONG).show()


                }
            }

        }

    }
    private fun delete()
    {
        delete_button.setOnClickListener()
        {
            if(id.text.toString().isEmpty()) {
                Toast.makeText(this,"ID required",Toast.LENGTH_LONG).show()

            } else {
                try
                {
                    dbhelper.delete_data(id.text.toString())
                    Toast.makeText(this,"Data deleted successfully ",Toast.LENGTH_LONG).show()
                    clear()
                }
                catch (e:Exception)
                {
                    e.printStackTrace()
                    Toast.makeText(this,"Couldn't Delete",Toast.LENGTH_LONG).show()


                }
            }
        }

    }
    private fun show() {
        read_button.setOnClickListener()
        {
            val buffer = StringBuffer()
            val res = dbhelper.showdata
            if (res.count == 0) {
                buffer.append("No data found")
                //Toast.makeText(this, "No data found", Toast.LENGTH_LONG).show()
            }

            while (res.moveToNext()) {
                buffer.append("ID - " + res.getString(0) + "\n")
                buffer.append("NAME - " + res.getString(1) + "\n")
                buffer.append("AGE - " + res.getString(2) + "\n")

            }
            showDialog("Student Data", buffer.toString())
        }

    }
}
