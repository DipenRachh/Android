package com.fredie.androidlayouts

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_list_view.*

class ListView : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view)

        var mobileNames = arrayOf("Apple","Samsung","OnePlus","Nokia","Xiaomi")

        var arrayAdapter=ArrayAdapter<String>(this,R.layout.list_view_item,R.id.label,mobileNames)

        list_view.adapter= arrayAdapter
    }
}
