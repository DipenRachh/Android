package com.fredie.androidlayouts

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_absolute_layout.*
import kotlinx.android.synthetic.main.activity_linear_layout.*

class AbsoluteLayout : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_absolute_layout)

        absolute_submit_button.setOnClickListener {
            if(absolute_input.text.toString().isEmpty()){
                Toast.makeText(this,"please fill all fields", Toast.LENGTH_LONG).show()
            } else{
                Toast.makeText(this,"you entered "+absolute_input.text.toString(),Toast.LENGTH_SHORT).show()

            }
        }
    }
}
