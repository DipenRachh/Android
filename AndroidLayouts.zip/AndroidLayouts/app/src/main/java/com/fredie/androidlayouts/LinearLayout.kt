package com.fredie.androidlayouts

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_linear_layout.*

class LinearLayout : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_linear_layout)


        linear_submit_button.setOnClickListener {
            if(linear_input.text.toString().isEmpty()){
                Toast.makeText(this,"please fill all fields",Toast.LENGTH_LONG).show()
            } else{
                display_area.text = "you entered "+linear_input.text.toString();

            }
        }
    }
}
