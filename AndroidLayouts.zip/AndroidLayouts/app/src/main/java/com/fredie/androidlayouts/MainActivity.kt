package com.fredie.androidlayouts

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        linear_layout_button.setOnClickListener {
            val intent = Intent(this,LinearLayout::class.java)
            startActivity(intent)
        }

        relative_layout_button.setOnClickListener {
            val intent = Intent(this,RelativeLayout::class.java)
            startActivity(intent)
        }

        table_layout_button.setOnClickListener {
            val intent = Intent(this,TableLayout::class.java)
            startActivity(intent)
        }

        list_view_layout_button.setOnClickListener {
            val intent = Intent(this,ListView::class.java)
            startActivity(intent)
        }

        grid_view_layout_button.setOnClickListener {
            val intent = Intent(this,GridView::class.java)
            startActivity(intent)
        }

        absolute_layout_button.setOnClickListener {
            val intent = Intent(this,AbsoluteLayout::class.java)
            startActivity(intent)
        }
    }
}
