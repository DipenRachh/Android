package com.fredie.androidlayouts

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_linear_layout.*
import kotlinx.android.synthetic.main.activity_table_layout.*

class TableLayout : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_table_layout)

        table_submit_button.setOnClickListener {
            if(table_input.text.toString().isEmpty()){
                Toast.makeText(this,"please fill all fields", Toast.LENGTH_LONG).show()
            } else{
                Toast.makeText(this,"you entered "+table_input.text.toString(), Toast.LENGTH_LONG).show()
            }
        }
    }
}
