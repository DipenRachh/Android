package com.fredie.androidlayouts

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_grid_view.*

class GridView : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_grid_view)



        btn_1.setOnClickListener {
            Toast.makeText(this,"1",Toast.LENGTH_LONG).show()
        }

        btn_2.setOnClickListener {
            Toast.makeText(this,"2",Toast.LENGTH_LONG).show()
        }

        btn_3.setOnClickListener {
            Toast.makeText(this,"3",Toast.LENGTH_LONG).show()
        }

        btn_4.setOnClickListener {
            Toast.makeText(this,"4",Toast.LENGTH_LONG).show()
        }

        btn_5.setOnClickListener {
            Toast.makeText(this,"5",Toast.LENGTH_LONG).show()
        }

        btn_6.setOnClickListener {
            Toast.makeText(this,"6",Toast.LENGTH_LONG).show()
        }

        btn_7.setOnClickListener {
            Toast.makeText(this,"7",Toast.LENGTH_LONG).show()
        }

        btn_8.setOnClickListener {
            Toast.makeText(this,"8",Toast.LENGTH_LONG).show()
        }

        btn_9.setOnClickListener {
            Toast.makeText(this,"9",Toast.LENGTH_LONG).show()
        }
    }
}
