package com.fredie.androidlayouts

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_linear_layout.*
import kotlinx.android.synthetic.main.activity_relative_layout.*

class RelativeLayout : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_relative_layout)

        relative_submit_button.setOnClickListener {
            if(relative_input.text.toString().isEmpty()){
                Toast.makeText(this,"please fill all fields", Toast.LENGTH_LONG).show()
            } else{
                Toast.makeText(this,"you entered "+relative_input.text, Toast.LENGTH_LONG).show()

            }
        }
    }
}
