package com.fredie.p12permissions

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private val PERMISSION_REQUEST_CODE = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn.setOnClickListener {
            if(Build.VERSION.SDK_INT>=23){

                if (checkPermission()) {
                    Toast.makeText(this,"Permission already granted",Toast.LENGTH_LONG).show()
                } else {
                    requestPermission()
                }
            }
        }
    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA),PERMISSION_REQUEST_CODE)
    }

    private fun checkPermission(): Boolean {

        var result = ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)

        return result == PackageManager.PERMISSION_GRANTED

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this,
                        "Permission granted", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this,
                        "Permission denied", Toast.LENGTH_LONG).show()
                }
            }
            else->{
                Toast.makeText(this,
                    "Permission required to continue", Toast.LENGTH_LONG).show()
            }
        }
    }

}
